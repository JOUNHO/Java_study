package ch08.exam04;


public class Car {
	public Tire t1;
	public Tire t2;
	public Tire t3;
	public Tire t4;

	public void run() {
		t1.roll();
		t2.roll();
		t3.roll();
		t4.roll();
	}

}
