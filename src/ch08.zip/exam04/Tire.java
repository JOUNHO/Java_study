package ch08.exam04;

public interface Tire {
	void roll();
}
