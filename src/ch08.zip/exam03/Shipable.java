package ch08.exam03;

public interface Shipable {
	void sailing();
	void anchor();
}
