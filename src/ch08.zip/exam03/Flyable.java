package ch08.exam03;

public interface Flyable {
	void takeoff();
	void land();
	void fly();
}
