package ch07.exam07;

public class Child extends Parent{
	

	@Override
	public void method2() {
		System.out.println("method2(Child)");
	}
	
	public void method3() {
		System.out.println("method3(Child)");
	}
}
