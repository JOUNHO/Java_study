package ch07.exam06.pack1;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
