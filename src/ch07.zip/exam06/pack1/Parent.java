package ch07.exam06.pack1;

public class Parent {
	protected int field1;
	
	protected void parentMethod() {
		System.out.println("ParentMethod");
	}
	
}
