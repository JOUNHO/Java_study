package ch07.exam06.pack2;

import ch07.exam06.pack1.Parent;

public class Child extends Parent{

}
