package ch07.exam04;

public class Example {
	public static void main(String[] args) {
		HomeActivity ha=new HomeActivity();
		ha.onCreate();
	}
}
