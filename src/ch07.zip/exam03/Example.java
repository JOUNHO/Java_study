package ch07.exam03;

public class Example {

	public static void main(String[] args) {
		Child child=new Child();
		
		child.field1=1;
		child.fiedl2=2;
		
		child.method1();
		child.method2();
	}

}
