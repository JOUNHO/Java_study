package ch07.exam10;

public class Parent {

	public int field1;
	
	public void method1() {
		System.out.println("method1(Parent)");
	}
	public void method2() {
		System.out.println("method2(Parent)");
	}
}
