package ch07.exam09;

public class taxi extends Vehicle{
	@Override
	public void run() {
	System.out.println("taxi�� �޸��ϴ�.");
	}
}
