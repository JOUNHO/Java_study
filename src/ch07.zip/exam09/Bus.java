package ch07.exam09;

public class Bus extends Vehicle{
	@Override
	public void run() {
	System.out.println("Bus�� �޸��ϴ�.");
	}
}
