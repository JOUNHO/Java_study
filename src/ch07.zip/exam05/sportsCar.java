package ch07.exam05;

public class sportsCar extends Car{

	@Override
	public void run() {
		super.run();
}
	
}
