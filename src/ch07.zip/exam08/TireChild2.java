package ch07.exam08;

public class TireChild2 extends Tire{
@Override
public void roll() {
	System.out.println("TireChild2 �� ȸ���մϴ�.");
}
}
