package ch07.exam08;

public class Tire {
	//Field
	//constructor
	//method
	public void roll() {
		System.out.println("�Ϲ� Ÿ�̾ ȸ���մϴ�.");
	}
}
