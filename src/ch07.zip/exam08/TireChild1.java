package ch07.exam08;

public class TireChild1 extends Tire{

	@Override
	public void roll() {
		System.out.println("TireChild1 �� ȸ���մϴ�.");
	}
}
